<?php 
session_start();
include('includes/config.php');
error_reporting(0);

?>

<!DOCTYPE HTML>
<html lang="en">
<head>

    <title>Car Rental Portal</title>
    <!--Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon-icon/apple-touch-icon-114-precomposed.html">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet"> 
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="assets/css/custom.css" type="text/css">
</head>
<body>



    <!--Header-->
    <?php include('includes/header.php');?>
    <!-- /Header --> 

    <!-- Banners -->
    <section class="home" id="home">

        <h3 data-speed="-2" class="home-parallax">find your car</h3>

        <img data-speed="5" class="home-parallax" src="../image/home-img.png" alt="">

        <a href="#" class="btn home-parallax">explore cars</a>

    </section>
    <!-- /Banners --> 
    <section class="icons-container">

        <div class="icons">
            <i class="fas fa-home"></i>
            <div class="content">
                <h3>150+</h3>
                <p>branches</p>
            </div>
        </div>

        <div class="icons">
            <i class="fas fa-car"></i>
            <div class="content">
                <h3>4770+</h3>
                <p>cars sold</p>
            </div>
        </div>

        <div class="icons">
            <i class="fas fa-users"></i>
            <div class="content">
                <h3>320+</h3>
                <p>happy clients</p>
            </div>
        </div>

        <div class="icons">
            <i class="fas fa-car"></i>
            <div class="content">
                <h3>1500+</h3>
                <p>new cars</p>
            </div>
        </div>

    </section>

    <section class="services" id="services">

        <h1 class="heading"> Our <span>Services</span> </h1>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-car"></i>
                <h3>car Selling</h3>
                <p>Selling your car made simple </p>
                <a href="#" class="btn"> read more</a>
            </div>

            <div class="box">
                <i class="fas fa-tools"></i>
                <h3>Parts Repair</h3>
                <p>Repair and support for car components.</p>
                <a href="#" class="btn"> read more</a>
            </div>

            <div class="box">
                <i class="fas fa-car-crash"></i>
                <h3>Car Insurance</h3>
                <p>Buy car insurance policy easily</p>
                <a href="#" class="btn"> read more</a>
            </div>

            <div class="box">
                <i class="fas fa-car-battery"></i>
                <h3>Battery Replacement</h3>
                <p>We've got you covered with Reliable Car Batteries</p>
                <a href="#" class="btn"> read more</a>
            </div>

            <div class="box">
                <i class="fas fa-gas-pump"></i>
                <h3>Oil Change</h3>
                <p>We provide best Oil for your car </p>
                <a href="#" class="btn"> read more</a>
            </div>

            <div class="box">
                <i class="fas fa-headset"></i>
                <h3>24/7 support</h3>
                <p>We support all the time</p>
                <a href="#" class="btn"> read more</a>
            </div>

        </div>

    </section>
    <!-- Resent Cat-->
    <section class="section-padding gray-bg ">
      <div class="container">
        <div class="section-header text-center">
          <h2>Find the Best <span>CarForYou</span></h2>

      </div>
      <div class="row"> 

          <!-- Nav tabs -->
          <div class="recent-tab">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#resentnewcar" role="tab" data-toggle="tab">New Car</a></li>
          </ul>
      </div>
      <!-- Recently Listed New Cars -->
      <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="resentnewcar">

            <?php $sql = "SELECT tblvehicles.VehiclesTitle,tblbrands.BrandName,tblvehicles.PricePerDay,tblvehicles.FuelType,tblvehicles.ModelYear,tblvehicles.id,tblvehicles.SeatingCapacity,tblvehicles.VehiclesOverview,tblvehicles.Vimage1 from tblvehicles join tblbrands on tblbrands.id=tblvehicles.VehiclesBrand and tblvehicles.emergency='No' limit 9";
            $query = $dbh -> prepare($sql);
            $query->execute();
            $results=$query->fetchAll(PDO::FETCH_OBJ);
            $cnt=1;
            if($query->rowCount() > 0)
            {
                foreach($results as $result)
                {  
                    ?>  

                    <div class="col-list-3">
                        <div class="recent-car-list">
                            <div class="car-info-box"> <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"><img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1);?>" class="img-responsive" alt="image"></a>
                                <ul>
                                    <li><i class="fa fa-car" aria-hidden="true"></i><?php echo htmlentities($result->FuelType);?></li>
                                    <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo htmlentities($result->ModelYear);?> Model</li>
                                    <li><i class="fa fa-user" aria-hidden="true"></i><?php echo htmlentities($result->SeatingCapacity);?> seats</li>
                                </ul>
                            </div>
                            <div class="car-title-m">
                                <h6><a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"> <?php echo htmlentities($result->VehiclesTitle);?></a></h6>
                                <span class="price">Rs. <?php echo htmlentities($result->PricePerDay);?> /Day</span> 
                            </div>
                            <div class="inventory_info_m">
                                <p><?php echo substr($result->VehiclesOverview,0,70);?></p>
                            </div>
                        </div>
                    </div>
                <?php }}?>

            </div>
        </div>
    </div>
</section>
<!-- /Resent Cat --> 
<!-- Emergency Car Section -->
<section class="section-padding gray-bg ">
  <div class="container">
    <div class="section-header text-center">
      <h2>Emergency <span>Cars</span></h2>

  </div>
  <div class="row"> 

      <!-- Nav tabs -->
      <div class="recent-tab">

      </div>
      <!-- Recently Listed New Cars -->
      <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="resentnewcar">

            <?php
            $emergency='Yes';
            $sql = "SELECT tblvehicles.VehiclesTitle,tblbrands.BrandName,tblvehicles.PricePerDay,tblvehicles.FuelType,tblvehicles.ModelYear,tblvehicles.id,tblvehicles.SeatingCapacity,tblvehicles.VehiclesOverview,tblvehicles.Vimage1 from tblvehicles  join tblbrands on tblbrands.id=tblvehicles.VehiclesBrand where tblvehicles.emergency='Yes' limit 3";
            $query = $dbh -> prepare($sql);
            $query->execute();
            $results=$query->fetchAll(PDO::FETCH_OBJ);
            $cnt=1;
            if($query->rowCount() > 0)
            {
                foreach($results as $result)
                {  
                    ?>  

                    <div class="col-list-3">
                        <div class="recent-car-list">
                            <div class="car-info-box"> <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"><img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1);?>" class="img-responsive" alt="image"></a>
                                <ul>
                                    <li><i class="fa fa-car" aria-hidden="true"></i><?php echo htmlentities($result->FuelType);?></li>
                                    <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo htmlentities($result->ModelYear);?> Model</li>
                                    <li><i class="fa fa-user" aria-hidden="true"></i><?php echo htmlentities($result->SeatingCapacity);?> seats</li>
                                </ul>
                            </div>
                            <div class="car-title-m">
                                <h6><a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"> <?php echo htmlentities($result->VehiclesTitle);?></a></h6>
                                <span class="price">Rs. <?php echo htmlentities($result->PricePerDay);?> /Day</span> 
                            </div>
                            <div class="inventory_info_m">
                                <p><?php echo substr($result->VehiclesOverview,0,70);?></p>
                            </div>
                        </div>
                    </div>
                <?php }}?>

            </div>
        </div>
    </div>
</section>
<!-- Emergency car section -->
<!-- popular -->
<section class="vehicles" id="vehicles">

    <h1 class="heading"> Luxury <span>vehicles</span> </h1>

    <div class="swiper vehicles-slider">

        <div class="swiper-wrapper">
<?php
                $luxury='Yes';
                $sql = "SELECT tblvehicles.VehiclesTitle,tblbrands.BrandName,tblvehicles.PricePerDay,tblvehicles.FuelType,tblvehicles.ModelYear,tblvehicles.id,tblvehicles.SeatingCapacity,tblvehicles.VehiclesOverview,tblvehicles.Vimage1 from tblvehicles  join tblbrands on tblbrands.id=tblvehicles.VehiclesBrand where tblvehicles.luxury='Yes' limit 3";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                    foreach($results as $result)
                    {  
                        ?> 
            <div class="swiper-slide box">
                 

                        <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"><img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1);?>" alt=""></a>
                  
                    <div class="content">
                        <h3><?php echo htmlentities($result->VehiclesTitle);?></h3>
                        <div class="price"> <span>price : </span> Rs. <?php echo htmlentities($result->PricePerDay);?> </div>
                        <p>
                           
                            <span class="fas fa-circle"></span> <?php echo htmlentities($result->ModelYear);?>
                            <span class="fas fa-circle"></span>Seating Capacity: <?php echo htmlentities($result->SeatingCapacity);?>
                            <span class="fas fa-circle"></span> <?php echo htmlentities($result->FuelType);?>
                        </p>
                    </div>
                </div>
  <?php }}?>
            </div>

            <div class="swiper-pagination"></div>

        </div>

    </section>
    <!-- Poupular section end -->
    <!-- Fun Facts-->
    <section class="fun-facts-section">
      <div class="container div_zindex">
        <div class="row">
          <div class="col-lg-3 col-xs-6 col-sm-3">
            <div class="fun-facts-m">
              <div class="cell">
                <h2><i class="fa fa-calendar" aria-hidden="true"></i>40+</h2>
                <p>Years In Business</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-car" aria-hidden="true"></i>1200+</h2>
            <p>New Cars For Sale</p>
        </div>
    </div>
</div>
<div class="col-lg-3 col-xs-6 col-sm-3">
    <div class="fun-facts-m">
      <div class="cell">
        <h2><i class="fa fa-car" aria-hidden="true"></i>1000+</h2>
        <p>Used Cars For Sale</p>
    </div>
</div>
</div>
<div class="col-lg-3 col-xs-6 col-sm-3">
    <div class="fun-facts-m">
      <div class="cell">
        <h2><i class="fa fa-user-circle-o" aria-hidden="true"></i>600+</h2>
        <p>Satisfied Customers</p>
    </div>
</div>
</div>
</div>
</div>
<!-- Dark Overlay-->
<div class="dark-overlay"></div>
</section>
<!-- /Fun Facts--> 


<!--Testimonial -->
<section class="section-padding testimonial-section parallex-bg">
  <div class="container div_zindex">
    <div class="section-header white-text text-center">
      <h2>Our Satisfied <span>Customers</span></h2>
  </div>
  <div class="row">
      <div id="testimonial-slider">
        <?php 
        $tid=1;
        $sql = "SELECT tbltestimonial.Testimonial,tblusers.FullName from tbltestimonial join tblusers on tbltestimonial.UserEmail=tblusers.EmailId where tbltestimonial.status=:tid limit 4";
        $query = $dbh -> prepare($sql);
        $query->bindParam(':tid',$tid, PDO::PARAM_STR);
        $query->execute();
        $results=$query->fetchAll(PDO::FETCH_OBJ);
        $cnt=1;
        if($query->rowCount() > 0)
        {
            foreach($results as $result)
                {  ?>


                    <div class="testimonial-m">

                      <div class="testimonial-content">
                        <div class="testimonial-heading">
                          <h5><?php echo htmlentities($result->FullName);?></h5>
                          <p><?php echo htmlentities($result->Testimonial);?></p>
                      </div>
                  </div>
              </div>
          <?php }} ?>



      </div>
  </div>
</div>
<!-- Dark Overlay-->
<div class="dark-overlay"></div>
</section>
<!-- /Testimonial--> 


<section class="contact" id="contact">

    <h1 class="heading"><span>contact</span> us</h1>

    <div class="row">

        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30153.788252261566!2d72.82321484621745!3d19.141690214227783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b63aceef0c69%3A0x2aa80cf2287dfa3b!2sJogeshwari%20West%2C%20Mumbai%2C%20Maharashtra%20400047!5e0!3m2!1sen!2sin!4v1632137920043!5m2!1sen!2sin" allowfullscreen="" loading="lazy"></iframe>

        <form action="">
            <h3>get in touch</h3>
            <input type="text" placeholder="your name" class="box">
            <input type="email" placeholder="your email" class="box">
            <input type="tel" placeholder="subject" class="box">
            <textarea placeholder="your message" class="box" cols="30" rows="10"></textarea>
            <input type="submit" value="send message" class="btn">
        </form>

    </div>

</section>
<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>

<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form --> 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<!--Switcher-->
<script src="assets/switcher/js/switcher.js"></script>
<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<script src="../js/script.js"></script>
</body>


</html>
